document.getElementById('year').textContent = new Date().getFullYear();
document.getElementById('hamburger').onclick = () => {
  const m = document.getElementById('menu');
  m.style.display = m.style.display === 'flex' ? 'none' : 'flex';
};
